import { SHOW_HOURLY } from "../constants/actions-types";
export const showHM = showHV => ({ type: SHOW_HOURLY, payload: showHV });
