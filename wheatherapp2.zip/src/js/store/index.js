import { createStore } from "redux";
import rootReducer from "../reducers/index";
import {showHM } from "../actions/index";
const store = createStore(rootReducer);
window.store = store;
window.showHM=showHM;
export default store;