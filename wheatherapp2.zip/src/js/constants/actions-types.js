
export const SHOW_HOURLY = "SHOW_HOURLY";