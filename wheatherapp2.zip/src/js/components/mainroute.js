import React, {Component} from 'react';
import { connect } from "react-redux";
import { showHM } from "../actions/index";


const mapStateToProps = state => {
  	return {
    
    }
};

const mapDispatchToProps = dispatch => {
	debugger
  return {
    showHM: showHV => dispatch(showHM(showHV)),
  };
};
export class MainComponent extends Component{
  constructor(props){
    super(props);
    this.state={
      data:props
    }
  }

  _changeValue(){
    debugger
    this.setState({
      data:{
        showHV:true
      }
    })
  }
  render(){
    debugger
    return(
			<div>
        <h1>Value jjn 
        <input type="text" readOnly={this.props.data.showHV}/> </h1>
				<button onClick={this._changeValue.bind(this)}>Change Value</button>
			</div>
    )
  }
}
var  MainComponent1 = connect( mapStateToProps, mapDispatchToProps)(MainComponent);
export default MainComponent1;