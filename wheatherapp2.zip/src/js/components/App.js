import React from "react";
import TODO1 from "./List";
import { Provider } from "react-redux";
import store from "../store";
const App = () => (
  <Provider store={store}>
    <div className="row mt-5">
      <div className="col-md-4 offset-md-1">
      <h2>ToDO List</h2>

        <TODO1 />
      </div>
    </div>
  </Provider>
);
export default App;