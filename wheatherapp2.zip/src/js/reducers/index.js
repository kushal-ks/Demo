
import { SHOW_HOURLY } from "../constants/actions-types";

const initialState = {
  showHV:false,
  showDV:true
};
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case SHOW_HOURLY:
      return{
        showDV:false,
        showHV:true
  }
    default:
      return state;
  }
};
export default rootReducer;