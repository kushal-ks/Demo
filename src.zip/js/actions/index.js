import { ADD_ITEM } from "../constants/actions-types";
import { ADD_DATA } from "../constants/actions-types";
import { DELETE_DATA } from "../constants/actions-types";

export const addItem = myList => ({ type: ADD_ITEM, payload: myList });
export const addData = myData => ({ type: ADD_DATA, payload: myData });
export const removeItem = myList =>({ type: DELETE_DATA, payload: myList})