import React, { Component } from "react";
import { connect } from "react-redux";
import { addItem } from "../actions/index";
import { addData } from "../actions/index";
import { removeItem } from "../actions/index";


const mapStateToProps = state => {
  debugger
  return (
    { myList: state.myList }
  );
};

const mapDispatchToProps = dispatch => {
  return {
    addItem: myList=> dispatch(addItem(myList)),
    addData: myData => dispatch(addData(myData)),
    removeItem: myList => dispatch(removeItem(myList))
  };
};


// const ConnectedList = ({ myList }) => (
//   <div>
//     <ul className="list-group list-group-flush">
//       {myList.map(el => (
//         <li className="list-group-item">
//           {el}
//           <button onClick={() => this._remove.bind(this, el)} value={el.value} className="Close btn" style={{ float: 'right', fontSize: 20, color: '' }}>X</button>
//         </li>
//       ))}
//     </ul>
//   </div>
// );



class ConnectedList extends Component {
  constructor(props)
  {
    super(props);
    debugger
    this.myList = this.props.myList;
  }

  _remove(e) {
    debugger
    var List=[];
      List = this.props.myList.filter(function (item) {
      debugger
      return item.toLowerCase() !==
        e.target.value.toLowerCase();
      });
    debugger
      this.props.removeItem(List);
      debugger
  }
  
  render() {
    debugger
    return (
      <div>
        <ul className="list-group list-group-flush">
          {this.props.myList.map(el => (
            <li className="list-group-item">
              {el}
              <button onClick={this._remove.bind(this)} value={el} className="Close btn" style={{ float: 'right', fontSize: 20, color: '' }}>X</button>
            </li>
          ))}
        </ul>
      </div>
    )

  }

}


class TODO extends Component {
  constructor() {
    super();
    this.state = {
      newList: []
    }
    this.remove = this._remove.bind(this);
  }
  _add(e) {
    e.preventDefault();
    var myData = document.getElementById('data');
    this.props.addItem(myData.value);
    myData.value = "";
  }
  _remove(e, data) {
    var List = this.state.myList.filter(function (item) {
      return item.value.toLowerCase() !==
        e.value.toLowerCase();
    });
  }
  render() {
    return (
      <center>
        <div className="Tododiv">
          <form>
            <div className="InputArea"> <input type="text" placeholder="Thing to do ToDay" id="data" className="InputField btn" />
              <button className="btn" onClick={this._add.bind(this)} >ADD</button>
            </div>
          </form>
          <div>
            <div class="Innerdiv" style={{ height: 500 }}>
              <List />
            </div>
          </div>
        </div>
      </center>
    )
  }
}

var  List = connect( mapStateToProps, mapDispatchToProps)(ConnectedList);
const TODO1 = connect(null, mapDispatchToProps)(TODO);
export default TODO1;