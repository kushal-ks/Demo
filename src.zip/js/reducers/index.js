
import { ADD_ITEM } from "../constants/actions-types";
import { ADD_DATA } from "../constants/actions-types";
import { DELETE_DATA } from "../constants/actions-types";

const initialState = {
  myList:[],
  data: []
};
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_ITEM:
      return { ...state, myList: [...state.myList, action.payload] };
    case ADD_DATA:
      return {...state, myList:[...state.data, action.payload]};
    case DELETE_DATA:
      return {     
        myList: action.payload
      }
    default:
      return state;
  }
};
export default rootReducer;