import { createStore } from "redux";
import rootReducer from "../reducers/index";
import { addItem } from "../actions/index";
import { addData } from "../actions/index";
import { removeItem  } from "../actions/index";

const store = createStore(rootReducer);
window.store = store;
window.addItem = addItem;
window.addData= addData;
export default store;